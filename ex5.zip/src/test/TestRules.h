/*
 * student 1: ahmed sarsour. 315397059
 * student 2: Eliad Arzuan 206482622
 */

#ifndef REVERSITESTS_TESTRULES_H
#define REVERSITESTS_TESTRULES_H
#include "gtest/gtest.h"
/*
 * Test the rules class (in our case BasicRUles) functions.
 */
class TestRules : public testing::Test{
protected:
};
#endif //REVERSITESTS_TESTRULES_H
