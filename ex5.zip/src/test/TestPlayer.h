/*
 * student 1: ahmed sarsour. 315397059
 * student 2: Eliad Arzuan 206482622
 */
/**
 * TestPlayer.
 * Class that tests player funcitons.
 */
#ifndef TESTPLAYER_H
#define TESTPLAYER_H
#include "gtest/gtest.h"
class TestPlayer: public testing::Test {
};
#endif //TESTPLAYER_H
